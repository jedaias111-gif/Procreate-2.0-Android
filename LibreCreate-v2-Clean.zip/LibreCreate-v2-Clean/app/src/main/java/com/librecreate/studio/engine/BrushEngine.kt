package com.librecreate.studio.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import com.librecreate.studio.model.BrushPreset
import com.librecreate.studio.model.BrushTipShape
import com.librecreate.studio.model.ToolMode
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

class BrushEngine {

    private val stampCache = mutableMapOf<BrushTipShape, Bitmap>()
    private val stampPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val matrix = Matrix()
    private val random = Random(42)

    private var smudgeCarryColor: Int = Color.TRANSPARENT
    private var hasSmudgeSample: Boolean = false

    fun beginStroke(
        targetBitmap: Bitmap,
        startX: Float,
        startY: Float,
        mode: ToolMode
    ) {
        hasSmudgeSample = false
        smudgeCarryColor = Color.TRANSPARENT
        if (mode == ToolMode.SMUDGE) {
            sampleSmudgeColor(targetBitmap, startX, startY, 1.0f)
        }
    }

    fun stampSegment(
        targetCanvas: Canvas,
        targetBitmap: Bitmap,
        preset: BrushPreset,
        mode: ToolMode,
        color: Int,
        baseSizePx: Float,
        baseOpacity: Float,
        alphaLock: Boolean,
        x0: Float,
        y0: Float,
        p0: Float,
        x1: Float,
        y1: Float,
        p1: Float,
        tiltRad: Float
    ) {
        val dist = hypot(x1 - x0, y1 - y0)
        val effectiveSize = max(1.5f, baseSizePx)
        val step = max(1.0f, effectiveSize * preset.spacingRatio)
        val steps = max(1, (dist / step).toInt())
        val angleDeg = (atan2(y1 - y0, x1 - x0) * 180.0 / PI).toFloat()

        var savedLayerCount = -1
        if (alphaLock && mode != ToolMode.ERASER) {
            savedLayerCount = targetCanvas.saveLayer(0f, 0f, targetBitmap.width.toFloat(), targetBitmap.height.toFloat(), null)
        }

        for (i in 0..steps) {
            val t = if (steps == 0) 1f else i.toFloat() / steps.toFloat()
            var x = x0 + (x1 - x0) * t
            var y = y0 + (y1 - y0) * t
            val pressure = (p0 + (p1 - p0) * t).coerceIn(0.05f, 1.0f)

            if (preset.scatter > 0f) {
                val scatterRadius = effectiveSize * preset.scatter
                x += (random.nextFloat() * 2f - 1f) * scatterRadius
                y += (random.nextFloat() * 2f - 1f) * scatterRadius
            }

            val sizeFactor = (1f - preset.pressureSizeInfluence) + preset.pressureSizeInfluence * pressure
            val tiltMultiplier = if (preset.tiltShadingEnabled && tiltRad > 0.25f) {
                1f + ((tiltRad - 0.25f) * 1.4f).coerceIn(0f, 1.2f)
            } else 1f

            val stampDiameter = max(1.5f, effectiveSize * sizeFactor * tiltMultiplier)
            val opacityFactor = (1f - preset.pressureOpacityInfluence) + preset.pressureOpacityInfluence * pressure
            val finalAlpha = (baseOpacity * preset.flow * opacityFactor * 255f).toInt().coerceIn(1, 255)

            when (mode) {
                ToolMode.BRUSH -> {
                    stampPaint.xfermode = null
                    stampPaint.colorFilter = PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN)
                    stampPaint.alpha = finalAlpha
                    drawTipStamp(targetCanvas, preset.tipShape, x, y, stampDiameter, if (preset.angleFollowsStroke) angleDeg else 0f)
                }

                ToolMode.ERASER -> {
                    stampPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
                    stampPaint.colorFilter = null
                    stampPaint.alpha = finalAlpha
                    drawTipStamp(targetCanvas, preset.tipShape, x, y, stampDiameter, if (preset.angleFollowsStroke) angleDeg else 0f)
                }

                ToolMode.SMUDGE -> {
                    sampleSmudgeColor(targetBitmap, x, y, (baseOpacity * 0.45f).coerceIn(0.12f, 0.75f))
                    if (hasSmudgeSample && Color.alpha(smudgeCarryColor) > 4) {
                        stampPaint.xfermode = null
                        stampPaint.colorFilter = PorterDuffColorFilter(smudgeCarryColor, PorterDuff.Mode.SRC_IN)
                        stampPaint.alpha = (finalAlpha * 0.72f).toInt().coerceIn(8, 220)
                        drawTipStamp(targetCanvas, preset.tipShape, x, y, stampDiameter, if (preset.angleFollowsStroke) angleDeg else 0f)
                    }
                }
            }
        }

        if (savedLayerCount != -1) {
            val maskPaint = Paint().apply {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            }
            targetCanvas.drawBitmap(targetBitmap, 0f, 0f, maskPaint)
            targetCanvas.restoreToCount(savedLayerCount)
        }
    }

    private fun sampleSmudgeColor(bitmap: Bitmap, x: Float, y: Float, blendWeight: Float) {
        val ix = x.toInt().coerceIn(0, bitmap.width - 1)
        val iy = y.toInt().coerceIn(0, bitmap.height - 1)
        val underPixel = bitmap.getPixel(ix, iy)
        if (!hasSmudgeSample) {
            smudgeCarryColor = underPixel
            hasSmudgeSample = true
        } else if (Color.alpha(underPixel) > 0) {
            val inv = 1f - blendWeight
            val a = (Color.alpha(smudgeCarryColor) * inv + Color.alpha(underPixel) * blendWeight).toInt().coerceIn(0, 255)
            val r = (Color.red(smudgeCarryColor) * inv + Color.red(underPixel) * blendWeight).toInt().coerceIn(0, 255)
            val g = (Color.green(smudgeCarryColor) * inv + Color.green(underPixel) * blendWeight).toInt().coerceIn(0, 255)
            val b = (Color.blue(smudgeCarryColor) * inv + Color.blue(underPixel) * blendWeight).toInt().coerceIn(0, 255)
            smudgeCarryColor = Color.argb(a, r, g, b)
        }
    }

    private fun drawTipStamp(
        canvas: Canvas,
        shape: BrushTipShape,
        cx: Float,
        cy: Float,
        diameter: Float,
        rotationDeg: Float
    ) {
        val tipBmp = getOrCreateTipBitmap(shape)
        val scale = diameter / tipBmp.width.toFloat()
        matrix.reset()
        matrix.postTranslate(-tipBmp.width / 2f, -tipBmp.height / 2f)
        if (rotationDeg != 0f) {
            matrix.postRotate(rotationDeg)
        }
        matrix.postScale(scale, scale)
        matrix.postTranslate(cx, cy)
        canvas.drawBitmap(tipBmp, matrix, stampPaint)
    }

    fun getOrCreateTipBitmap(shape: BrushTipShape): Bitmap {
        stampCache[shape]?.let { return it }
        val size = 128
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val half = size / 2f
        val rng = Random(shape.ordinal * 997 + 13)

        when (shape) {
            BrushTipShape.ROUND_HARD -> {
                p.color = Color.WHITE
                c.drawCircle(half, half, half * 0.94f, p)
            }

            BrushTipShape.ROUND_SOFT -> {
                p.shader = RadialGradient(
                    half, half, half * 0.96f,
                    intArrayOf(Color.WHITE, Color.argb(140, 255, 255, 255), Color.TRANSPARENT),
                    floatArrayOf(0f, 0.45f, 1f),
                    Shader.TileMode.CLAMP
                )
                c.drawCircle(half, half, half * 0.96f, p)
            }

            BrushTipShape.PENCIL_GRAIN -> {
                for (i in 0 until 420) {
                    val angle = rng.nextFloat() * 2f * PI.toFloat()
                    val r = rng.nextFloat() * half * 0.92f
                    val px = half + cos(angle) * r
                    val py = half + sin(angle) * r
                    p.color = Color.argb(rng.nextInt(90, 255), 255, 255, 255)
                    c.drawCircle(px, py, rng.nextFloat() * 2.6f + 0.8f, p)
                }
            }

            BrushTipShape.CHARCOAL_GRAIN -> {
                for (i in 0 until 260) {
                    val angle = rng.nextFloat() * 2f * PI.toFloat()
                    val r = rng.nextFloat() * half * 0.95f
                    val px = half + cos(angle) * r
                    val py = half + sin(angle) * r
                    p.color = Color.argb(rng.nextInt(70, 240), 255, 255, 255)
                    c.drawRect(px - 3f, py - 2f, px + 3f, py + 2f, p)
                }
            }

            BrushTipShape.CALLIGRAPHY_FLAT -> {
                p.color = Color.WHITE
                c.save()
                c.rotate(-32f, half, half)
                c.drawRoundRect(half * 0.12f, half * 0.72f, size - half * 0.12f, size - half * 0.72f, 10f, 10f, p)
                c.restore()
            }

            BrushTipShape.BRISTLE_RAKE -> {
                for (i in 0 until 28) {
                    val bx = half * 0.25f + rng.nextFloat() * (size * 0.75f)
                    val by = half * 0.30f + rng.nextFloat() * (size * 0.70f)
                    p.color = Color.argb(rng.nextInt(130, 255), 255, 255, 255)
                    c.drawCircle(bx, by, rng.nextFloat() * 5.5f + 2.5f, p)
                }
            }

            BrushTipShape.SPLATTER -> {
                for (i in 0 until 18) {
                    val angle = rng.nextFloat() * 2f * PI.toFloat()
                    val r = rng.nextFloat() * half * 0.90f
                    val px = half + cos(angle) * r
                    val py = half + sin(angle) * r
                    p.color = Color.argb(rng.nextInt(160, 255), 255, 255, 255)
                    c.drawCircle(px, py, rng.nextFloat() * 8f + 2f, p)
                }
            }

            BrushTipShape.HALFTONE -> {
                p.color = Color.WHITE
                val step = 24f
                var y = 16f
                while (y < size - 10f) {
                    var x = 16f
                    while (x < size - 10f) {
                        if (hypot(x - half, y - half) < half * 0.88f) {
                            c.drawCircle(x, y, 6.2f, p)
                        }
                        x += step
                    }
                    y += step
                }
            }
        }
        stampCache[shape] = bmp
        return bmp
    }

    fun renderBrushPreview(preset: BrushPreset, width: Int, height: Int): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val steps = 48
        for (i in 0 until steps) {
            val t0 = i.toFloat() / steps
            val t1 = (i + 1).toFloat() / steps
            val x0 = 18f + t0 * (width - 36f)
            val x1 = 18f + t1 * (width - 36f)
            val y0 = height / 2f + sin(t0 * 2f * PI).toFloat() * (height * 0.24f)
            val y1 = height / 2f + sin(t1 * 2f * PI).toFloat() * (height * 0.24f)
            val p0 = sin(t0 * PI).toFloat().coerceIn(0.15f, 1.0f)
            val p1 = sin(t1 * PI).toFloat().coerceIn(0.15f, 1.0f)

            stampSegment(
                targetCanvas = canvas,
                targetBitmap = bmp,
                preset = preset,
                mode = ToolMode.BRUSH,
                color = Color.WHITE,
                baseSizePx = 14f,
                baseOpacity = 1.0f,
                alphaLock = false,
                x0 = x0,
                y0 = y0,
                p0 = p0,
                x1 = x1,
                y1 = y1,
                p1 = p1,
                tiltRad = 0f
            )
        }
        return bmp
    }
}
