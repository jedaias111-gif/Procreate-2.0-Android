package com.librecreate.studio.model

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode

enum class LayerBlendMode(val label: String, val xfermode: PorterDuffXfermode?) {
    NORMAL("Normal", null),
    MULTIPLY("Multiplicar", PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)),
    SCREEN("Trama", PorterDuffXfermode(PorterDuff.Mode.SCREEN)),
    OVERLAY("Superponer", PorterDuffXfermode(PorterDuff.Mode.OVERLAY)),
    ADD("Añadir", PorterDuffXfermode(PorterDuff.Mode.ADD)),
    DARKEN("Oscurecer", PorterDuffXfermode(PorterDuff.Mode.DARKEN)),
    LIGHTEN("Aclarar", PorterDuffXfermode(PorterDuff.Mode.LIGHTEN))
}

enum class SymmetryMode(val label: String) {
    NONE("Sin Simetría"),
    VERTICAL("Simetría Vertical"),
    HORIZONTAL("Simetría Horizontal"),
    QUADRANT("Simetría Cuadrante (4x)"),
    RADIAL_8("Mandala Radial (8x)")
}

class LayerItem(
    val id: Long,
    var name: String,
    val bitmap: Bitmap,
    var isVisible: Boolean = true,
    var opacity: Float = 1.0f,
    var blendMode: LayerBlendMode = LayerBlendMode.NORMAL,
    var alphaLock: Boolean = false
) {
    val canvas: Canvas = Canvas(bitmap)

    fun copyLayer(newId: Long, newName: String): LayerItem {
        val clonedBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        return LayerItem(
            id = newId,
            name = newName,
            bitmap = clonedBitmap,
            isVisible = isVisible,
            opacity = opacity,
            blendMode = blendMode,
            alphaLock = alphaLock
        )
    }
}
