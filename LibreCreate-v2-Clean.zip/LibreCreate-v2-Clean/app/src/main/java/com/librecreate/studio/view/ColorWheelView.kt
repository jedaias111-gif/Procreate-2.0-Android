package com.librecreate.studio.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ComposeShader
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

class ColorWheelView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var hue: Float = 217f
    private var saturation: Float = 0.76f
    private var brightness: Float = 0.96f

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val selectorStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = Color.WHITE
    }
    private val selectorShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 8f
        color = Color.BLACK
    }

    private var activeZone = 0
    var onColorChanged: ((Int) -> Unit)? = null

    fun setColor(color: Int) {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hue = hsv[0]
        saturation = hsv[1]
        brightness = hsv[2]
        invalidate()
    }

    fun getCurrentColor(): Int = Color.HSVToColor(floatArrayOf(hue, saturation, brightness))

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val outerR = min(cx, cy) - 8f
        val ringThickness = outerR * 0.20f
        val midR = outerR - ringThickness / 2f

        val hueColors = intArrayOf(
            Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED
        )
        ringPaint.strokeWidth = ringThickness
        ringPaint.shader = SweepGradient(cx, cy, hueColors, null)
        canvas.drawCircle(cx, cy, midR, ringPaint)

        val rad = Math.toRadians(hue.toDouble())
        val hx = cx + (cos(rad) * midR).toFloat()
        val hy = cy + (sin(rad) * midR).toFloat()
        canvas.drawCircle(hx, hy, ringThickness * 0.42f, selectorShadow)
        canvas.drawCircle(hx, hy, ringThickness * 0.42f, selectorStroke)

        val innerR = outerR - ringThickness - 10f
        val halfBox = innerR * 0.70f
        val left = cx - halfBox
        val top = cy - halfBox
        val right = cx + halfBox
        val bottom = cy + halfBox

        val pureHueColor = Color.HSVToColor(floatArrayOf(hue, 1f, 1f))
        val satShader = LinearGradient(left, top, right, top, Color.WHITE, pureHueColor, Shader.TileMode.CLAMP)
        val valShader = LinearGradient(left, top, left, bottom, Color.TRANSPARENT, Color.BLACK, Shader.TileMode.CLAMP)
        boxPaint.shader = ComposeShader(satShader, valShader, PorterDuff.Mode.SRC_OVER)
        canvas.drawRect(left, top, right, bottom, boxPaint)

        val sx = left + saturation * (right - left)
        val sy = top + (1f - brightness) * (bottom - top)
        canvas.drawCircle(sx, sy, 12f, selectorShadow)
        canvas.drawCircle(sx, sy, 12f, selectorStroke)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val cx = width / 2f
        val cy = height / 2f
        val outerR = min(cx, cy) - 8f
        val ringThickness = outerR * 0.20f
        val innerR = outerR - ringThickness - 10f
        val halfBox = innerR * 0.70f

        val dx = event.x - cx
        val dy = event.y - cy
        val dist = hypot(dx, dy)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activeZone = if (dist >= innerR) 1 else 2
                updateFromTouch(event.x, event.y, cx, cy, halfBox)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                updateFromTouch(event.x, event.y, cx, cy, halfBox)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activeZone = 0
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun updateFromTouch(tx: Float, ty: Float, cx: Float, cy: Float, halfBox: Float) {
        if (activeZone == 1) {
            val angle = (atan2(ty - cy, tx - cx) * 180.0 / PI).toFloat()
            hue = (angle + 360f) % 360f
        } else if (activeZone == 2) {
            val left = cx - halfBox
            val top = cy - halfBox
            val size = halfBox * 2f
            saturation = ((tx - left) / size).coerceIn(0f, 1f)
            brightness = 1f - ((ty - top) / size).coerceIn(0f, 1f)
        }
        invalidate()
        onColorChanged?.invoke(getCurrentColor())
    }
}
