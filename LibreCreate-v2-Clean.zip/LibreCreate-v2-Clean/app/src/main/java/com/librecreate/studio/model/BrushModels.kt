package com.librecreate.studio.model

enum class ToolMode {
    BRUSH,
    SMUDGE,
    ERASER
}

enum class BrushCategory(val title: String) {
    SKETCHING("Boceto"),
    INKING("Entintado"),
    PAINTING("Pintura"),
    AIRBRUSH("Aerógrafo"),
    TEXTURES("Texturas")
}

enum class BrushTipShape {
    ROUND_HARD,
    ROUND_SOFT,
    PENCIL_GRAIN,
    CHARCOAL_GRAIN,
    CALLIGRAPHY_FLAT,
    BRISTLE_RAKE,
    SPLATTER,
    HALFTONE
}

data class BrushPreset(
    val id: String,
    val name: String,
    val subtitle: String,
    val category: BrushCategory,
    val tipShape: BrushTipShape,
    val spacingRatio: Float,
    val pressureSizeInfluence: Float,
    val pressureOpacityInfluence: Float,
    val tiltShadingEnabled: Boolean,
    val flow: Float,
    val scatter: Float = 0f,
    val angleFollowsStroke: Boolean = false
)

object BrushCatalog {
    val allBrushes: List<BrushPreset> = listOf(
        BrushPreset(
            id = "hb_pencil",
            name = "Lápiz HB",
            subtitle = "Grafito con sombreado por inclinación",
            category = BrushCategory.SKETCHING,
            tipShape = BrushTipShape.PENCIL_GRAIN,
            spacingRatio = 0.08f,
            pressureSizeInfluence = 0.45f,
            pressureOpacityInfluence = 0.75f,
            tiltShadingEnabled = true,
            flow = 0.65f
        ),
        BrushPreset(
            id = "6b_pencil",
            name = "Lápiz 6B Suave",
            subtitle = "Trazo oscuro y cremoso para bocetos",
            category = BrushCategory.SKETCHING,
            tipShape = BrushTipShape.PENCIL_GRAIN,
            spacingRatio = 0.06f,
            pressureSizeInfluence = 0.60f,
            pressureOpacityInfluence = 0.65f,
            tiltShadingEnabled = true,
            flow = 0.85f
        ),
        BrushPreset(
            id = "charcoal",
            name = "Carboncillo Artístico",
            subtitle = "Textura orgánica de grano grueso",
            category = BrushCategory.SKETCHING,
            tipShape = BrushTipShape.CHARCOAL_GRAIN,
            spacingRatio = 0.12f,
            pressureSizeInfluence = 0.70f,
            pressureOpacityInfluence = 0.80f,
            tiltShadingEnabled = true,
            flow = 0.75f
        ),
        BrushPreset(
            id = "tech_pen",
            name = "Pluma Técnica",
            subtitle = "Línea limpia y constante para lineart",
            category = BrushCategory.INKING,
            tipShape = BrushTipShape.ROUND_HARD,
            spacingRatio = 0.04f,
            pressureSizeInfluence = 0.30f,
            pressureOpacityInfluence = 0.05f,
            tiltShadingEnabled = false,
            flow = 1.0f
        ),
        BrushPreset(
            id = "studio_pen",
            name = "Pluma de Estudio",
            subtitle = "Alta variación de grosor por presión",
            category = BrushCategory.INKING,
            tipShape = BrushTipShape.ROUND_HARD,
            spacingRatio = 0.04f,
            pressureSizeInfluence = 0.92f,
            pressureOpacityInfluence = 0.10f,
            tiltShadingEnabled = false,
            flow = 1.0f
        ),
        BrushPreset(
            id = "syrup_ink",
            name = "Tinta Syrup",
            subtitle = "Entintado fluido estilo cómic e ilustración",
            category = BrushCategory.INKING,
            tipShape = BrushTipShape.ROUND_HARD,
            spacingRatio = 0.03f,
            pressureSizeInfluence = 0.85f,
            pressureOpacityInfluence = 0.0f,
            tiltShadingEnabled = false,
            flow = 1.0f
        ),
        BrushPreset(
            id = "calligraphy_nib",
            name = "Plumilla Caligráfica",
            subtitle = "Punta biselada dinámica según dirección",
            category = BrushCategory.INKING,
            tipShape = BrushTipShape.CALLIGRAPHY_FLAT,
            spacingRatio = 0.04f,
            pressureSizeInfluence = 0.75f,
            pressureOpacityInfluence = 0.05f,
            tiltShadingEnabled = false,
            flow = 1.0f,
            angleFollowsStroke = true
        ),
        BrushPreset(
            id = "round_bristle",
            name = "Pincel Redondo Cerdas",
            subtitle = "Cerdas múltiples con mezcla natural",
            category = BrushCategory.PAINTING,
            tipShape = BrushTipShape.BRISTLE_RAKE,
            spacingRatio = 0.07f,
            pressureSizeInfluence = 0.65f,
            pressureOpacityInfluence = 0.55f,
            tiltShadingEnabled = false,
            flow = 0.80f,
            angleFollowsStroke = true
        ),
        BrushPreset(
            id = "oil_flat",
            name = "Óleo Plano",
            subtitle = "Pincelada densa con textura pictórica",
            category = BrushCategory.PAINTING,
            tipShape = BrushTipShape.CALLIGRAPHY_FLAT,
            spacingRatio = 0.06f,
            pressureSizeInfluence = 0.50f,
            pressureOpacityInfluence = 0.45f,
            tiltShadingEnabled = true,
            flow = 0.90f,
            angleFollowsStroke = true
        ),
        BrushPreset(
            id = "watercolor_wash",
            name = "Acuarela Translúcida",
            subtitle = "Veladuras suaves acumulables",
            category = BrushCategory.PAINTING,
            tipShape = BrushTipShape.ROUND_SOFT,
            spacingRatio = 0.10f,
            pressureSizeInfluence = 0.55f,
            pressureOpacityInfluence = 0.70f,
            tiltShadingEnabled = false,
            flow = 0.28f
        ),
        BrushPreset(
            id = "soft_airbrush",
            name = "Aerógrafo Suave",
            subtitle = "Degradado radial ultra difuso",
            category = BrushCategory.AIRBRUSH,
            tipShape = BrushTipShape.ROUND_SOFT,
            spacingRatio = 0.08f,
            pressureSizeInfluence = 0.40f,
            pressureOpacityInfluence = 0.85f,
            tiltShadingEnabled = false,
            flow = 0.35f
        ),
        BrushPreset(
            id = "hard_airbrush",
            name = "Aerógrafo Medio",
            subtitle = "Sombreado suave con borde definido",
            category = BrushCategory.AIRBRUSH,
            tipShape = BrushTipShape.ROUND_SOFT,
            spacingRatio = 0.06f,
            pressureSizeInfluence = 0.50f,
            pressureOpacityInfluence = 0.75f,
            tiltShadingEnabled = false,
            flow = 0.60f
        ),
        BrushPreset(
            id = "splatter_fx",
            name = "Salpicadura Orgánica",
            subtitle = "Partículas dispersas para atmósfera",
            category = BrushCategory.TEXTURES,
            tipShape = BrushTipShape.SPLATTER,
            spacingRatio = 0.25f,
            pressureSizeInfluence = 0.60f,
            pressureOpacityInfluence = 0.50f,
            tiltShadingEnabled = false,
            flow = 0.85f,
            scatter = 0.45f
        ),
        BrushPreset(
            id = "halftone_dots",
            name = "Trama Semitono (Manga)",
            subtitle = "Puntos regulares estilo cómic impreso",
            category = BrushCategory.TEXTURES,
            tipShape = BrushTipShape.HALFTONE,
            spacingRatio = 0.22f,
            pressureSizeInfluence = 0.40f,
            pressureOpacityInfluence = 0.40f,
            tiltShadingEnabled = false,
            flow = 0.95f
        )
    )
}
