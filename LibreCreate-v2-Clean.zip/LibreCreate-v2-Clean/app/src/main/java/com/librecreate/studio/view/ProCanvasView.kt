package com.librecreate.studio.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.librecreate.studio.engine.BrushEngine
import com.librecreate.studio.engine.UndoManager
import com.librecreate.studio.model.BrushCatalog
import com.librecreate.studio.model.BrushPreset
import com.librecreate.studio.model.LayerItem
import com.librecreate.studio.model.SymmetryMode
import com.librecreate.studio.model.ToolMode
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

class ProCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var canvasWidth: Int = 1600
        private set
    var canvasHeight: Int = 2200
        private set

    val layers = mutableListOf<LayerItem>()
    var activeLayerIndex: Int = 0
    var backgroundColor: Int = Color.WHITE
    var isBackgroundVisible: Boolean = true

    val brushEngine = BrushEngine()
    val undoManager = UndoManager(maxSteps = 30)

    var currentToolMode: ToolMode = ToolMode.BRUSH
    var currentBrushPreset: BrushPreset = BrushCatalog.allBrushes.first { it.id == "tech_pen" }
    var currentColor: Int = Color.parseColor("#3B82F6")
    var brushSizePx: Float = 24f
    var brushOpacity: Float = 1.0f
    var streamlineAmount: Float = 0.35f
    var symmetryMode: SymmetryMode = SymmetryMode.NONE
    var isEyedropperActive: Boolean = false

    var onLayersChanged: (() -> Unit)? = null
    var onZoomChanged: ((Float) -> Unit)? = null
    var onColorPicked: ((Int) -> Unit)? = null
    var onGestureMessage: ((String) -> Unit)? = null

    private val viewMatrix = Matrix()
    private val inverseMatrix = Matrix()
    private val matrixValues = FloatArray(9)

    private var isDrawing = false
    private var strokeBeforeBitmap: Bitmap? = null
    private var lastX = 0f
    private var lastY = 0f
    private var lastPressure = 1f
    private var nextLayerId = 1L

    private var isNavigating = false
    private var prevFocusX = 0f
    private var prevFocusY = 0f
    private var prevSpan = 0f
    private var prevAngle = 0f
    private var multiTouchStartTime = 0L
    private var maxPointerCountInGesture = 0
    private var multiTouchMoved = false

    private var eyedropperScreenX = -1f
    private var eyedropperScreenY = -1f
    private var eyedropperPreviewColor = Color.WHITE

    private val layerPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val bgPaint = Paint()
    private val shadowPaint = Paint().apply {
        color = Color.argb(120, 0, 0, 0)
    }
    private val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(170, 59, 130, 246)
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private val checkerLight = Paint().apply { color = Color.parseColor("#2A2A32") }
    private val checkerDark = Paint().apply { color = Color.parseColor("#1E1E24") }

    init {
        initNewDocument(1600, 2200)
    }

    fun initNewDocument(w: Int, h: Int) {
        undoManager.clearAll()
        layers.forEach { it.bitmap.recycle() }
        layers.clear()

        canvasWidth = w
        canvasHeight = h
        backgroundColor = Color.WHITE
        isBackgroundVisible = true
        nextLayerId = 1L

        addLayer("Capa 1")
        post { fitCanvasToScreen() }
        onLayersChanged?.invoke()
    }

    fun fitCanvasToScreen() {
        if (width == 0 || height == 0) return
        val margin = 0.88f
        val scale = min(
            (width * margin) / canvasWidth.toFloat(),
            (height * margin) / canvasHeight.toFloat()
        )
        viewMatrix.reset()
        viewMatrix.postScale(scale, scale)
        viewMatrix.postTranslate(
            (width - canvasWidth * scale) / 2f,
            (height - canvasHeight * scale) / 2f
        )
        notifyZoom()
        invalidate()
    }

    fun getCurrentZoomScale(): Float {
        viewMatrix.getValues(matrixValues)
        return hypot(matrixValues[Matrix.MSCALE_X], matrixValues[Matrix.MSKEW_Y])
    }

    private fun notifyZoom() {
        onZoomChanged?.invoke(getCurrentZoomScale())
    }

    fun addLayer(customName: String? = null): LayerItem {
        val bmp = Bitmap.createBitmap(canvasWidth, canvasHeight, Bitmap.Config.ARGB_8888)
        val layer = LayerItem(
            id = nextLayerId++,
            name = customName ?: "Capa ${layers.size + 1}",
            bitmap = bmp
        )
        val insertIndex = if (layers.isEmpty()) 0 else (activeLayerIndex + 1).coerceAtMost(layers.size)
        layers.add(insertIndex, layer)
        activeLayerIndex = insertIndex
        onLayersChanged?.invoke()
        invalidate()
        return layer
    }

    fun duplicateActiveLayer() {
        val current = getActiveLayer() ?: return
        val copy = current.copyLayer(nextLayerId++, "${current.name} (Copia)")
        layers.add(activeLayerIndex + 1, copy)
        activeLayerIndex += 1
        onLayersChanged?.invoke()
        invalidate()
    }

    fun deleteLayerAt(index: Int) {
        if (layers.size <= 1 || index !in layers.indices) return
        val removed = layers.removeAt(index)
        removed.bitmap.recycle()
        activeLayerIndex = activeLayerIndex.coerceIn(0, layers.size - 1)
        onLayersChanged?.invoke()
        invalidate()
    }

    fun mergeActiveLayerDown() {
        if (activeLayerIndex <= 0 || activeLayerIndex >= layers.size) return
        val upper = layers[activeLayerIndex]
        val lower = layers[activeLayerIndex - 1]
        val before = lower.bitmap.copy(Bitmap.Config.ARGB_8888, true)

        val p = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            alpha = (upper.opacity * 255f).toInt().coerceIn(0, 255)
            xfermode = upper.blendMode.xfermode
        }
        lower.canvas.drawBitmap(upper.bitmap, 0f, 0f, p)
        val after = lower.bitmap.copy(Bitmap.Config.ARGB_8888, true)
        undoManager.recordAction(lower.id, before, after)

        layers.removeAt(activeLayerIndex)
        upper.bitmap.recycle()
        activeLayerIndex -= 1
        onLayersChanged?.invoke()
        invalidate()
    }

    fun clearActiveLayer() {
        val layer = getActiveLayer() ?: return
        val before = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true)
        layer.bitmap.eraseColor(Color.TRANSPARENT)
        val after = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true)
        undoManager.recordAction(layer.id, before, after)
        onLayersChanged?.invoke()
        invalidate()
    }

    fun getActiveLayer(): LayerItem? = layers.getOrNull(activeLayerIndex)

    fun performUndo(): Boolean {
        val entry = undoManager.popUndo() ?: return false
        val layer = layers.firstOrNull { it.id == entry.layerId } ?: return false
        layer.bitmap.eraseColor(Color.TRANSPARENT)
        layer.canvas.drawBitmap(entry.beforeBitmap, 0f, 0f, null)
        onLayersChanged?.invoke()
        invalidate()
        return true
    }

    fun performRedo(): Boolean {
        val entry = undoManager.popRedo() ?: return false
        val layer = layers.firstOrNull { it.id == entry.layerId } ?: return false
        layer.bitmap.eraseColor(Color.TRANSPARENT)
        layer.canvas.drawBitmap(entry.afterBitmap, 0f, 0f, null)
        onLayersChanged?.invoke()
        invalidate()
        return true
    }

    fun renderFlattenedBitmap(includeBackground: Boolean = true): Bitmap {
        val out = Bitmap.createBitmap(canvasWidth, canvasHeight, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        if (includeBackground && isBackgroundVisible) {
            c.drawColor(backgroundColor)
        }
        for (layer in layers) {
            if (!layer.isVisible) continue
            layerPaint.alpha = (layer.opacity * 255f).toInt().coerceIn(0, 255)
            layerPaint.xfermode = layer.blendMode.xfermode
            c.drawBitmap(layer.bitmap, 0f, 0f, layerPaint)
        }
        layerPaint.xfermode = null
        layerPaint.alpha = 255
        return out
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.save()
        canvas.concat(viewMatrix)

        canvas.drawRect(14f, 14f, canvasWidth + 14f, canvasHeight + 14f, shadowPaint)

        if (isBackgroundVisible) {
            bgPaint.color = backgroundColor
            canvas.drawRect(0f, 0f, canvasWidth.toFloat(), canvasHeight.toFloat(), bgPaint)
        } else {
            drawTransparencyGrid(canvas)
        }

        for (layer in layers) {
            if (!layer.isVisible) continue
            layerPaint.alpha = (layer.opacity * 255f).toInt().coerceIn(0, 255)
            layerPaint.xfermode = layer.blendMode.xfermode
            canvas.drawBitmap(layer.bitmap, 0f, 0f, layerPaint)
        }
        layerPaint.xfermode = null
        layerPaint.alpha = 255

        drawSymmetryGuides(canvas)

        canvas.restore()

        if (isEyedropperActive && eyedropperScreenX >= 0f && eyedropperScreenY >= 0f) {
            drawEyedropperLoupe(canvas, eyedropperScreenX, eyedropperScreenY, eyedropperPreviewColor)
        }
    }

    private fun drawTransparencyGrid(canvas: Canvas) {
        val tile = 40f
        var y = 0f
        var row = 0
        while (y < canvasHeight) {
            var x = 0f
            var col = 0
            while (x < canvasWidth) {
                val p = if ((row + col) % 2 == 0) checkerLight else checkerDark
                canvas.drawRect(x, y, min(x + tile, canvasWidth.toFloat()), min(y + tile, canvasHeight.toFloat()), p)
                x += tile
                col++
            }
            y += tile
            row++
        }
    }

    private fun drawSymmetryGuides(canvas: Canvas) {
        val w = canvasWidth.toFloat()
        val h = canvasHeight.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        when (symmetryMode) {
            SymmetryMode.NONE -> Unit
            SymmetryMode.VERTICAL -> canvas.drawLine(cx, 0f, cx, h, guidePaint)
            SymmetryMode.HORIZONTAL -> canvas.drawLine(0f, cy, w, cy, guidePaint)
            SymmetryMode.QUADRANT -> {
                canvas.drawLine(cx, 0f, cx, h, guidePaint)
                canvas.drawLine(0f, cy, w, cy, guidePaint)
            }
            SymmetryMode.RADIAL_8 -> {
                canvas.drawLine(cx, 0f, cx, h, guidePaint)
                canvas.drawLine(0f, cy, w, cy, guidePaint)
                canvas.drawLine(0f, 0f, w, h, guidePaint)
                canvas.drawLine(w, 0f, 0f, h, guidePaint)
            }
        }
    }

    private fun drawEyedropperLoupe(canvas: Canvas, sx: Float, sy: Float, sampledColor: Int) {
        val radius = 78f
        val ringFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 18f
            color = sampledColor
        }
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3f
            color = Color.WHITE
        }
        canvas.drawCircle(sx, sy - 95f, radius, ringFill)
        canvas.drawCircle(sx, sy - 95f, radius + 9f, border)
        canvas.drawCircle(sx, sy - 95f, radius - 9f, border)
    }

    private fun screenToCanvas(sx: Float, sy: Float): FloatArray {
        viewMatrix.invert(inverseMatrix)
        val pts = floatArrayOf(sx, sy)
        inverseMatrix.mapPoints(pts)
        return pts
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val pointerCount = event.pointerCount

        if (pointerCount >= 2) {
            if (isDrawing) {
                cancelCurrentStroke()
            }
            handleMultiTouchGesture(event)
            return true
        }

        if (isNavigating) {
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                finishMultiTouchGesture()
            }
            return true
        }

        val pt = screenToCanvas(event.x, event.y)
        val cx = pt[0]
        val cy = pt[1]

        if (isEyedropperActive) {
            eyedropperScreenX = event.x
            eyedropperScreenY = event.y
            eyedropperPreviewColor = sampleCompositeColorAt(cx, cy)
            invalidate()
            if (event.actionMasked == MotionEvent.ACTION_UP) {
                isEyedropperActive = false
                eyedropperScreenX = -1f
                currentColor = eyedropperPreviewColor
                onColorPicked?.invoke(currentColor)
                invalidate()
            }
            return true
        }

        val layer = getActiveLayer() ?: return true
        val pressure = event.pressure.coerceIn(0.05f, 1.0f)
        val tilt = event.getAxisValue(MotionEvent.AXIS_TILT)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!layer.isVisible) {
                    onGestureMessage?.invoke("La capa activa está oculta")
                    return true
                }
                isDrawing = true
                strokeBeforeBitmap = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true)
                lastX = cx
                lastY = cy
                lastPressure = pressure
                brushEngine.beginStroke(layer.bitmap, cx, cy, currentToolMode)
                applySymmetryStamp(layer, cx, cy, pressure, cx, cy, pressure, tilt)
                invalidate()
            }

            MotionEvent.ACTION_MOVE -> {
                if (!isDrawing) return true
                val historySize = event.historySize
                for (h in 0 until historySize) {
                    val hPt = screenToCanvas(event.getHistoricalX(h), event.getHistoricalY(h))
                    val hPress = event.getHistoricalPressure(h).coerceIn(0.05f, 1.0f)
                    val smoothX = lastX + (hPt[0] - lastX) * (1f - streamlineAmount)
                    val smoothY = lastY + (hPt[1] - lastY) * (1f - streamlineAmount)
                    applySymmetryStamp(layer, lastX, lastY, lastPressure, smoothX, smoothY, hPress, tilt)
                    lastX = smoothX
                    lastY = smoothY
                    lastPressure = hPress
                }

                val smoothX = lastX + (cx - lastX) * (1f - streamlineAmount)
                val smoothY = lastY + (cy - lastY) * (1f - streamlineAmount)
                applySymmetryStamp(layer, lastX, lastY, lastPressure, smoothX, smoothY, pressure, tilt)
                lastX = smoothX
                lastY = smoothY
                lastPressure = pressure
                invalidate()
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (isDrawing) {
                    isDrawing = false
                    val before = strokeBeforeBitmap
                    if (before != null) {
                        val after = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true)
                        undoManager.recordAction(layer.id, before, after)
                        strokeBeforeBitmap = null
                    }
                    onLayersChanged?.invoke()
                    invalidate()
                }
            }
        }
        return true
    }

    private fun cancelCurrentStroke() {
        val layer = getActiveLayer()
        val before = strokeBeforeBitmap
        if (layer != null && before != null) {
            layer.bitmap.eraseColor(Color.TRANSPARENT)
            layer.canvas.drawBitmap(before, 0f, 0f, null)
            before.recycle()
        }
        strokeBeforeBitmap = null
        isDrawing = false
        invalidate()
    }

    private fun handleMultiTouchGesture(event: MotionEvent) {
        val count = event.pointerCount
        if (!isNavigating) {
            isNavigating = true
            multiTouchStartTime = System.currentTimeMillis()
            maxPointerCountInGesture = count
            multiTouchMoved = false
            updateGestureAnchors(event)
            return
        }

        if (count > maxPointerCountInGesture) {
            maxPointerCountInGesture = count
            updateGestureAnchors(event)
            return
        }

        if (event.actionMasked == MotionEvent.ACTION_POINTER_UP) {
            if (count <= 2) {
                finishMultiTouchGesture()
            }
            return
        }

        val fx = (event.getX(0) + event.getX(1)) / 2f
        val fy = (event.getY(0) + event.getY(1)) / 2f
        val span = hypot(event.getX(1) - event.getX(0), event.getY(1) - event.getY(0))
        val angle = (atan2(event.getY(1) - event.getY(0), event.getX(1) - event.getX(0)) * 180.0 / PI).toFloat()

        val dx = fx - prevFocusX
        val dy = fy - prevFocusY
        if (hypot(dx, dy) > 12f || kotlin.math.abs(span - prevSpan) > 14f) {
            multiTouchMoved = true
        }

        if (prevSpan > 10f && span > 10f) {
            val scaleFactor = (span / prevSpan).coerceIn(0.85f, 1.18f)
            val currentZoom = getCurrentZoomScale()
            val clampedScale = if (currentZoom * scaleFactor in 0.15f..12.0f) scaleFactor else 1.0f

            viewMatrix.postTranslate(dx, dy)
            viewMatrix.postScale(clampedScale, clampedScale, fx, fy)
            viewMatrix.postRotate(angle - prevAngle, fx, fy)
            notifyZoom()
            invalidate()
        }

        prevFocusX = fx
        prevFocusY = fy
        prevSpan = span
        prevAngle = angle
    }

    private fun updateGestureAnchors(event: MotionEvent) {
        if (event.pointerCount < 2) return
        prevFocusX = (event.getX(0) + event.getX(1)) / 2f
        prevFocusY = (event.getY(0) + event.getY(1)) / 2f
        prevSpan = hypot(event.getX(1) - event.getX(0), event.getY(1) - event.getY(0))
        prevAngle = (atan2(event.getY(1) - event.getY(0), event.getX(1) - event.getX(0)) * 180.0 / PI).toFloat()
    }

    private fun finishMultiTouchGesture() {
        val duration = System.currentTimeMillis() - multiTouchStartTime
        if (!multiTouchMoved && duration < 280L) {
            if (maxPointerCountInGesture == 2) {
                if (performUndo()) onGestureMessage?.invoke("Deshacer (Gesto 2 dedos)")
            } else if (maxPointerCountInGesture >= 3) {
                if (performRedo()) onGestureMessage?.invoke("Rehacer (Gesto 3 dedos)")
            }
        }
        isNavigating = false
        maxPointerCountInGesture = 0
        multiTouchMoved = false
    }

    private fun sampleCompositeColorAt(cx: Float, cy: Float): Int {
        val ix = cx.toInt().coerceIn(0, canvasWidth - 1)
        val iy = cy.toInt().coerceIn(0, canvasHeight - 1)
        for (i in layers.indices.reversed()) {
            val l = layers[i]
            if (!l.isVisible) continue
            val px = l.bitmap.getPixel(ix, iy)
            if (Color.alpha(px) > 20) {
                return Color.rgb(Color.red(px), Color.green(px), Color.blue(px))
            }
        }
        return if (isBackgroundVisible) backgroundColor else Color.WHITE
    }

    private fun applySymmetryStamp(
        layer: LayerItem,
        x0: Float, y0: Float, p0: Float,
        x1: Float, y1: Float, p1: Float,
        tiltRad: Float
    ) {
        val w = canvasWidth.toFloat()
        val h = canvasHeight.toFloat()

        stampSingle(layer, x0, y0, p0, x1, y1, p1, tiltRad)

        when (symmetryMode) {
            SymmetryMode.NONE -> Unit
            SymmetryMode.VERTICAL -> {
                stampSingle(layer, w - x0, y0, p0, w - x1, y1, p1, tiltRad)
            }
            SymmetryMode.HORIZONTAL -> {
                stampSingle(layer, x0, h - y0, p0, x1, h - y1, p1, tiltRad)
            }
            SymmetryMode.QUADRANT -> {
                stampSingle(layer, w - x0, y0, p0, w - x1, y1, p1, tiltRad)
                stampSingle(layer, x0, h - y0, p0, x1, h - y1, p1, tiltRad)
                stampSingle(layer, w - x0, h - y0, p0, w - x1, h - y1, p1, tiltRad)
            }
            SymmetryMode.RADIAL_8 -> {
                val cx = w / 2f
                val cy = h / 2f
                for (step in 1 until 8) {
                    val rad = (step * PI / 4.0)
                    val rx0 = cx + ((x0 - cx) * cos(rad) - (y0 - cy) * sin(rad)).toFloat()
                    val ry0 = cy + ((x0 - cx) * sin(rad) + (y0 - cy) * cos(rad)).toFloat()
                    val rx1 = cx + ((x1 - cx) * cos(rad) - (y1 - cy) * sin(rad)).toFloat()
                    val ry1 = cy + ((x1 - cx) * sin(rad) + (y1 - cy) * cos(rad)).toFloat()
                    stampSingle(layer, rx0, ry0, p0, rx1, ry1, p1, tiltRad)
                }
            }
        }
    }

    private fun stampSingle(
        layer: LayerItem,
        x0: Float, y0: Float, p0: Float,
        x1: Float, y1: Float, p1: Float,
        tiltRad: Float
    ) {
        brushEngine.stampSegment(
            targetCanvas = layer.canvas,
            targetBitmap = layer.bitmap,
            preset = currentBrushPreset,
            mode = currentToolMode,
            color = currentColor,
            baseSizePx = brushSizePx,
            baseOpacity = brushOpacity,
            alphaLock = layer.alphaLock,
            x0 = x0, y0 = y0, p0 = p0,
            x1 = x1, y1 = y1, p1 = p1,
            tiltRad = tiltRad
        )
    }
}
