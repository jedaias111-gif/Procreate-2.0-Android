package com.librecreate.studio

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.librecreate.studio.databinding.ActivityMainBinding
import com.librecreate.studio.model.BrushCatalog
import com.librecreate.studio.model.BrushCategory
import com.librecreate.studio.model.BrushPreset
import com.librecreate.studio.model.LayerBlendMode
import com.librecreate.studio.model.SymmetryMode
import com.librecreate.studio.model.ToolMode
import com.librecreate.studio.ui.BrushAdapter
import com.librecreate.studio.ui.LayerAdapter

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var brushAdapter: BrushAdapter
    private lateinit var layerAdapter: LayerAdapter
    private val uiHandler = Handler(Looper.getMainLooper())

    private data class ToolConfig(
        var brush: BrushPreset,
        var sizePx: Float,
        var opacity: Float
    )

    private val toolConfigs = mutableMapOf(
        ToolMode.BRUSH to ToolConfig(BrushCatalog.allBrushes.first { it.id == "tech_pen" }, 22f, 1.0f),
        ToolMode.SMUDGE to ToolConfig(BrushCatalog.allBrushes.first { it.id == "soft_airbrush" }, 45f, 0.75f),
        ToolMode.ERASER to ToolConfig(BrushCatalog.allBrushes.first { it.id == "studio_pen" }, 34f, 1.0f)
    )

    private var activeCategory = BrushCategory.INKING

    private val paletteColors = intArrayOf(
        Color.parseColor("#000000"), Color.parseColor("#FFFFFF"),
        Color.parseColor("#EF4444"), Color.parseColor("#F97316"),
        Color.parseColor("#EAB308"), Color.parseColor("#22C55E"),
        Color.parseColor("#06B6D4"), Color.parseColor("#3B82F6"),
        Color.parseColor("#6366F1"), Color.parseColor("#A855F7"),
        Color.parseColor("#EC4899"), Color.parseColor("#F43F5E"),
        Color.parseColor("#FDE68A"), Color.parseColor("#D97706"),
        Color.parseColor("#78350F"), Color.parseColor("#64748B")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbarActions()
        setupLeftSliders()
        setupBrushLibraryPanel()
        setupLayersPanel()
        setupColorStudioPanel()
        setupCanvasCallbacks()

        selectToolMode(ToolMode.BRUSH, openPanelIfAlreadySelected = false)
        refreshLayersUI()
    }

    private fun setupCanvasCallbacks() {
        binding.proCanvasView.onLayersChanged = {
            runOnUiThread { refreshLayersUI() }
        }
        binding.proCanvasView.onZoomChanged = { scale ->
            val pct = (scale * 100f).toInt()
            binding.tvZoomReset.text = "$pct%"
        }
        binding.proCanvasView.onColorPicked = { color ->
            applyActiveColor(color)
            showStatusPill("Color muestreado: ${toHex(color)}")
        }
        binding.proCanvasView.onGestureMessage = { msg ->
            showStatusPill(msg)
        }
    }

    private fun setupToolbarActions() {
        binding.btnActions.setOnClickListener {
            closeAllPopovers()
            val options = arrayOf(
                "Nuevo Lienzo (1600 × 2200)",
                "Nuevo Lienzo Cuadrado (2048 × 2048)",
                "Nuevo Lienzo 4K Ultra (3840 × 2160)",
                "Exportar PNG a Galería",
                "Exportar PNG Transparente (Sin Fondo)",
                "Limpiar Capa Actual"
            )
            AlertDialog.Builder(this)
                .setTitle("Acciones de Lienzo")
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> binding.proCanvasView.initNewDocument(1600, 2200)
                        1 -> binding.proCanvasView.initNewDocument(2048, 2048)
                        2 -> binding.proCanvasView.initNewDocument(3840, 2160)
                        3 -> exportCanvasPng(includeBackground = true)
                        4 -> exportCanvasPng(includeBackground = false)
                        5 -> binding.proCanvasView.clearActiveLayer()
                    }
                }
                .show()
        }

        binding.btnSymmetry.setOnClickListener {
            val modes = SymmetryMode.values()
            val next = modes[(binding.proCanvasView.symmetryMode.ordinal + 1) % modes.size]
            binding.proCanvasView.symmetryMode = next
            binding.proCanvasView.invalidate()
            showStatusPill(next.label)
        }

        binding.tvZoomReset.setOnClickListener {
            binding.proCanvasView.fitCanvasToScreen()
            showStatusPill("Lienzo ajustado a pantalla")
        }

        binding.btnUndo.setOnClickListener {
            if (binding.proCanvasView.performUndo()) {
                showStatusPill("Deshacer")
            }
        }

        binding.btnRedo.setOnClickListener {
            if (binding.proCanvasView.performRedo()) {
                showStatusPill("Rehacer")
            }
        }

        binding.btnToolBrush.setOnClickListener {
            selectToolMode(ToolMode.BRUSH, openPanelIfAlreadySelected = true)
        }
        binding.btnToolSmudge.setOnClickListener {
            selectToolMode(ToolMode.SMUDGE, openPanelIfAlreadySelected = true)
        }
        binding.btnToolEraser.setOnClickListener {
            selectToolMode(ToolMode.ERASER, openPanelIfAlreadySelected = true)
        }

        binding.btnLayersContainer.setOnClickListener {
            togglePopover(binding.panelLayers)
            refreshLayersUI()
        }

        binding.btnColorWheel.setOnClickListener {
            togglePopover(binding.panelColors)
        }
    }

    private fun selectToolMode(mode: ToolMode, openPanelIfAlreadySelected: Boolean) {
        val alreadyActive = binding.proCanvasView.currentToolMode == mode
        binding.proCanvasView.currentToolMode = mode

        val cfg = toolConfigs[mode]!!
        binding.proCanvasView.currentBrushPreset = cfg.brush
        binding.proCanvasView.brushSizePx = cfg.sizePx
        binding.proCanvasView.brushOpacity = cfg.opacity

        binding.seekBrushSize.progress = cfg.sizePx.toInt().coerceIn(1, 250)
        binding.tvSizeLabel.text = "${cfg.sizePx.toInt()}px"
        binding.seekBrushOpacity.progress = (cfg.opacity * 100f).toInt().coerceIn(1, 100)
        binding.tvOpacityLabel.text = "${(cfg.opacity * 100f).toInt()}%"

        binding.btnToolBrush.setBackgroundResource(
            if (mode == ToolMode.BRUSH) R.drawable.bg_panel_rounded else android.R.color.transparent
        )
        binding.btnToolSmudge.setBackgroundResource(
            if (mode == ToolMode.SMUDGE) R.drawable.bg_panel_rounded else android.R.color.transparent
        )
        binding.btnToolEraser.setBackgroundResource(
            if (mode == ToolMode.ERASER) R.drawable.bg_panel_rounded else android.R.color.transparent
        )

        val title = when (mode) {
            ToolMode.BRUSH -> "Pinceles (${cfg.brush.name})"
            ToolMode.SMUDGE -> "Difuminador (${cfg.brush.name})"
            ToolMode.ERASER -> "Borrador (${cfg.brush.name})"
        }
        binding.tvBrushLibraryTitle.text = title
        brushAdapter.submitList(
            BrushCatalog.allBrushes.filter { it.category == activeCategory },
            cfg.brush.id
        )

        if (alreadyActive && openPanelIfAlreadySelected) {
            togglePopover(binding.panelBrushes)
        } else {
            closeAllPopovers()
            showStatusPill(title)
        }
    }

    private fun setupLeftSliders() {
        binding.seekBrushSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val sz = progress.coerceAtLeast(1).toFloat()
                binding.tvSizeLabel.text = "${sz.toInt()}px"
                binding.proCanvasView.brushSizePx = sz
                toolConfigs[binding.proCanvasView.currentToolMode]?.sizePx = sz
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        binding.seekBrushOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val op = (progress.coerceAtLeast(1) / 100f)
                binding.tvOpacityLabel.text = "${progress.coerceAtLeast(1)}%"
                binding.proCanvasView.brushOpacity = op
                toolConfigs[binding.proCanvasView.currentToolMode]?.opacity = op
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        binding.btnEyedropper.setOnClickListener {
            closeAllPopovers()
            val next = !binding.proCanvasView.isEyedropperActive
            binding.proCanvasView.isEyedropperActive = next
            showStatusPill(if (next) "Toca el lienzo para capturar color" else "Cuentagotas desactivado")
        }
    }

    private fun setupBrushLibraryPanel() {
        brushAdapter = BrushAdapter(binding.proCanvasView.brushEngine) { selectedBrush ->
            val mode = binding.proCanvasView.currentToolMode
            toolConfigs[mode]?.brush = selectedBrush
            binding.proCanvasView.currentBrushPreset = selectedBrush
            showStatusPill(selectedBrush.name)
        }
        binding.rvBrushes.layoutManager = LinearLayoutManager(this)
        binding.rvBrushes.adapter = brushAdapter

        binding.seekStreamline.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.proCanvasView.streamlineAmount = progress / 100f
                binding.tvStreamlineValue.text = "Estabilizador: $progress%"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        for (cat in BrushCategory.values()) {
            val btn = Button(this).apply {
                text = cat.title
                textSize = 11f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(if (cat == activeCategory) Color.parseColor("#3B82F6") else Color.parseColor("#27272E"))
                setPadding(24, 6, 24, 6)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    84
                ).apply { marginEnd = 10 }
                layoutParams = lp
                setOnClickListener {
                    activeCategory = cat
                    refreshCategoryButtons()
                    val currentId = binding.proCanvasView.currentBrushPreset.id
                    brushAdapter.submitList(
                        BrushCatalog.allBrushes.filter { it.category == cat },
                        currentId
                    )
                }
            }
            binding.layoutBrushCategories.addView(btn)
        }
    }

    private fun refreshCategoryButtons() {
        val categories = BrushCategory.values()
        for (i in 0 until binding.layoutBrushCategories.childCount) {
            val child = binding.layoutBrushCategories.getChildAt(i)
            child.setBackgroundColor(
                if (categories[i] == activeCategory) Color.parseColor("#3B82F6")
                else Color.parseColor("#27272E")
            )
        }
    }

    private fun setupLayersPanel() {
        layerAdapter = LayerAdapter(
            onSelectLayer = { idx ->
                binding.proCanvasView.activeLayerIndex = idx
                refreshLayersUI()
            },
            onToggleVisibility = { idx, visible ->
                binding.proCanvasView.layers.getOrNull(idx)?.isVisible = visible
                binding.proCanvasView.invalidate()
                refreshLayersUI()
            },
            onDeleteLayer = { idx ->
                binding.proCanvasView.deleteLayerAt(idx)
            }
        )
        binding.rvLayers.layoutManager = LinearLayoutManager(this)
        binding.rvLayers.adapter = layerAdapter

        binding.btnAddLayer.setOnClickListener {
            binding.proCanvasView.addLayer()
        }

        binding.seekLayerOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val layer = binding.proCanvasView.getActiveLayer() ?: return
                layer.opacity = progress / 100f
                binding.tvActiveLayerOpacity.text = "Opacidad Capa: $progress%"
                binding.proCanvasView.invalidate()
                layerAdapter.notifyDataSetChanged()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        binding.btnBlendMode.setOnClickListener {
            val layer = binding.proCanvasView.getActiveLayer() ?: return@setOnClickListener
            val modes = LayerBlendMode.values()
            val names = modes.map { it.label }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Modo de Fusión")
                .setItems(names) { _, which ->
                    layer.blendMode = modes[which]
                    binding.btnBlendMode.text = layer.blendMode.label
                    binding.proCanvasView.invalidate()
                    refreshLayersUI()
                }
                .show()
        }

        binding.btnAlphaLock.setOnClickListener {
            val layer = binding.proCanvasView.getActiveLayer() ?: return@setOnClickListener
            layer.alphaLock = !layer.alphaLock
            refreshLayersUI()
        }

        binding.btnMergeDown.setOnClickListener {
            binding.proCanvasView.mergeActiveLayerDown()
        }

        binding.btnDuplicateLayer.setOnClickListener {
            binding.proCanvasView.duplicateActiveLayer()
        }

        binding.cbBackgroundVisible.setOnCheckedChangeListener { _, isChecked ->
            binding.proCanvasView.isBackgroundVisible = isChecked
            binding.proCanvasView.invalidate()
        }

        binding.rowBackgroundLayer.setOnClickListener {
            val bgOptions = arrayOf("Blanco Puro", "Papel Crema Cálido", "Gris Neutro Boceto", "Negro Pizarra")
            val bgColors = intArrayOf(
                Color.WHITE,
                Color.parseColor("#FAF6EE"),
                Color.parseColor("#D4D4D8"),
                Color.parseColor("#18181B")
            )
            AlertDialog.Builder(this)
                .setTitle("Color de Fondo")
                .setItems(bgOptions) { _, which ->
                    binding.proCanvasView.backgroundColor = bgColors[which]
                    binding.viewBgColorPreview.setBackgroundColor(bgColors[which])
                    binding.proCanvasView.invalidate()
                }
                .show()
        }
    }

    private fun refreshLayersUI() {
        val layers = binding.proCanvasView.layers
        val activeIdx = binding.proCanvasView.activeLayerIndex
        binding.tvLayerCountBadge.text = "${layers.size}"
        layerAdapter.submitLayers(layers, activeIdx)

        val active = binding.proCanvasView.getActiveLayer() ?: return
        val opPct = (active.opacity * 100f).toInt()
        binding.tvActiveLayerOpacity.text = "Opacidad Capa: $opPct%"
        binding.seekLayerOpacity.progress = opPct
        binding.btnBlendMode.text = active.blendMode.label
        binding.btnAlphaLock.text = if (active.alphaLock) "Bloq. Alfa: ON" else "Bloq. Alfa: OFF"
    }

    private fun setupColorStudioPanel() {
        binding.colorWheelView.onColorChanged = { color ->
            applyActiveColor(color)
        }
        rebuildPaletteGrid()
        applyActiveColor(binding.proCanvasView.currentColor)
    }

    private fun applyActiveColor(color: Int) {
        binding.proCanvasView.currentColor = color
        binding.viewCurrentColorSwatch.setBackgroundColor(color)
        binding.tvHexColor.text = toHex(color)
        binding.colorWheelView.setColor(color)
        updateColorHarmonies(color)
    }

    private fun updateColorHarmonies(baseColor: Int) {
        binding.layoutHarmonySwatches.removeAllViews()
        val hsv = FloatArray(3)
        Color.colorToHSV(baseColor, hsv)
        val angles = floatArrayOf(0f, 180f, 30f, -30f, 120f, 240f)
        for (offset in angles) {
            val h = (hsv[0] + offset + 360f) % 360f
            val c = Color.HSVToColor(floatArrayOf(h, hsv[1], hsv[2]))
            val swatch = View(this).apply {
                setBackgroundColor(c)
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginEnd = 6
                }
                layoutParams = lp
                setOnClickListener { applyActiveColor(c) }
            }
            binding.layoutHarmonySwatches.addView(swatch)
        }
    }

    private fun rebuildPaletteGrid() {
        binding.gridPaletteSwatches.removeAllViews()
        for (i in paletteColors.indices) {
            val swatch = View(this).apply {
                setBackgroundColor(paletteColors[i])
                val lp = android.widget.GridLayout.LayoutParams().apply {
                    width = 0
                    height = 68
                    columnSpec = android.widget.GridLayout.spec(i % 8, 1f)
                    rowSpec = android.widget.GridLayout.spec(i / 8)
                    setMargins(4, 4, 4, 4)
                }
                layoutParams = lp
                setOnClickListener {
                    applyActiveColor(paletteColors[i])
                }
                setOnLongClickListener {
                    paletteColors[i] = binding.proCanvasView.currentColor
                    rebuildPaletteGrid()
                    showStatusPill("Color guardado en paleta")
                    true
                }
            }
            binding.gridPaletteSwatches.addView(swatch)
        }
    }

    private fun exportCanvasPng(includeBackground: Boolean) {
        val bitmap = binding.proCanvasView.renderFlattenedBitmap(includeBackground)
        val fileName = "LibreCreate_${System.currentTimeMillis()}.png"
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/LibreCreate")
                }
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                Toast.makeText(this, "Guardado en Imágenes/LibreCreate: $fileName", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error al exportar: ${e.message}", Toast.LENGTH_LONG).show()
        } finally {
            bitmap.recycle()
        }
    }

    private fun togglePopover(target: View) {
        val wasVisible = target.visibility == View.VISIBLE
        closeAllPopovers()
        if (!wasVisible) {
            target.visibility = View.VISIBLE
        }
    }

    private fun closeAllPopovers() {
        binding.panelBrushes.visibility = View.GONE
        binding.panelLayers.visibility = View.GONE
        binding.panelColors.visibility = View.GONE
    }

    private fun showStatusPill(text: String) {
        binding.tvStatusPill.text = text
        binding.tvStatusPill.visibility = View.VISIBLE
        uiHandler.removeCallbacksAndMessages(null)
        uiHandler.postDelayed({
            binding.tvStatusPill.visibility = View.GONE
        }, 1600L)
    }

    private fun toHex(color: Int): String = String.format("#%06X", 0xFFFFFF and color)
}
