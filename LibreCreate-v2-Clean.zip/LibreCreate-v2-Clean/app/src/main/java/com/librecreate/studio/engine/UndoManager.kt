package com.librecreate.studio.engine

import android.graphics.Bitmap

data class StrokeHistoryEntry(
    val layerId: Long,
    val beforeBitmap: Bitmap,
    val afterBitmap: Bitmap
)

class UndoManager(private val maxSteps: Int = 30) {
    private val undoStack = ArrayDeque<StrokeHistoryEntry>()
    private val redoStack = ArrayDeque<StrokeHistoryEntry>()

    fun recordAction(layerId: Long, before: Bitmap, after: Bitmap) {
        if (undoStack.size >= maxSteps) {
            val oldest = undoStack.removeFirst()
            oldest.beforeBitmap.recycle()
            oldest.afterBitmap.recycle()
        }
        undoStack.addLast(StrokeHistoryEntry(layerId, before, after))
        while (redoStack.isNotEmpty()) {
            val item = redoStack.removeLast()
            item.beforeBitmap.recycle()
            item.afterBitmap.recycle()
        }
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    fun popUndo(): StrokeHistoryEntry? {
        if (undoStack.isEmpty()) return null
        val entry = undoStack.removeLast()
        redoStack.addLast(entry)
        return entry
    }

    fun popRedo(): StrokeHistoryEntry? {
        if (redoStack.isEmpty()) return null
        val entry = redoStack.removeLast()
        undoStack.addLast(entry)
        return entry
    }

    fun clearAll() {
        while (undoStack.isNotEmpty()) {
            val e = undoStack.removeLast()
            e.beforeBitmap.recycle()
            e.afterBitmap.recycle()
        }
        while (redoStack.isNotEmpty()) {
            val e = redoStack.removeLast()
            e.beforeBitmap.recycle()
            e.afterBitmap.recycle()
        }
    }
}
