package com.librecreate.studio.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.librecreate.studio.R
import com.librecreate.studio.model.LayerItem

class LayerAdapter(
    private val onSelectLayer: (Int) -> Unit,
    private val onToggleVisibility: (Int, Boolean) -> Unit,
    private val onDeleteLayer: (Int) -> Unit
) : RecyclerView.Adapter<LayerAdapter.LayerVH>() {

    private var layers: List<LayerItem> = emptyList()
    private var activeIndex: Int = 0

    fun submitLayers(allLayers: List<LayerItem>, currentActiveIndex: Int) {
        layers = allLayers
        activeIndex = currentActiveIndex
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LayerVH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_layer, parent, false)
        return LayerVH(v)
    }

    override fun onBindViewHolder(holder: LayerVH, position: Int) {
        val realIndex = layers.size - 1 - position
        val layer = layers[realIndex]
        val isSelected = realIndex == activeIndex

        holder.tvName.text = if (layer.alphaLock) "${layer.name} [Alfa]" else layer.name
        holder.tvMeta.text = "${layer.blendMode.label} · ${(layer.opacity * 100).toInt()}%"
        holder.ivThumb.setImageBitmap(layer.bitmap)

        holder.root.setBackgroundColor(
            if (isSelected) Color.parseColor("#263B82F6") else Color.parseColor("#27272E")
        )

        holder.cbVisible.setOnCheckedChangeListener(null)
        holder.cbVisible.isChecked = layer.isVisible
        holder.cbVisible.setOnCheckedChangeListener { _, isChecked ->
            onToggleVisibility(realIndex, isChecked)
        }

        holder.btnDelete.visibility = if (layers.size > 1) View.VISIBLE else View.INVISIBLE
        holder.btnDelete.setOnClickListener {
            onDeleteLayer(realIndex)
        }

        holder.itemView.setOnClickListener {
            onSelectLayer(realIndex)
        }
    }

    override fun getItemCount(): Int = layers.size

    class LayerVH(view: View) : RecyclerView.ViewHolder(view) {
        val root: View = view.findViewById(R.id.layerItemRoot)
        val ivThumb: ImageView = view.findViewById(R.id.ivLayerThumb)
        val tvName: TextView = view.findViewById(R.id.tvLayerName)
        val tvMeta: TextView = view.findViewById(R.id.tvLayerMeta)
        val cbVisible: CheckBox = view.findViewById(R.id.cbLayerVisible)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDeleteLayer)
    }
}
