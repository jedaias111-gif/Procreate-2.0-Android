package com.librecreate.studio.ui

import android.graphics.Bitmap
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.librecreate.studio.R
import com.librecreate.studio.engine.BrushEngine
import com.librecreate.studio.model.BrushPreset

class BrushAdapter(
    private val brushEngine: BrushEngine,
    private val onSelectBrush: (BrushPreset) -> Unit
) : RecyclerView.Adapter<BrushAdapter.BrushVH>() {

    private var items: List<BrushPreset> = emptyList()
    private var selectedId: String = "tech_pen"
    private val previewCache = mutableMapOf<String, Bitmap>()

    fun submitList(newList: List<BrushPreset>, activeBrushId: String) {
        items = newList
        selectedId = activeBrushId
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BrushVH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_brush, parent, false)
        return BrushVH(v)
    }

    override fun onBindViewHolder(holder: BrushVH, position: Int) {
        val brush = items[position]
        holder.tvName.text = brush.name
        holder.tvSub.text = brush.subtitle

        val isSelected = brush.id == selectedId
        holder.root.setBackgroundColor(
            if (isSelected) Color.parseColor("#263B82F6") else Color.parseColor("#27272E")
        )

        val preview = previewCache.getOrPut(brush.id) {
            brushEngine.renderBrushPreview(brush, 220, 64)
        }
        holder.ivPreview.setImageBitmap(preview)

        holder.itemView.setOnClickListener {
            selectedId = brush.id
            notifyDataSetChanged()
            onSelectBrush(brush)
        }
    }

    override fun getItemCount(): Int = items.size

    class BrushVH(view: View) : RecyclerView.ViewHolder(view) {
        val root: View = view.findViewById(R.id.brushItemRoot)
        val tvName: TextView = view.findViewById(R.id.tvBrushName)
        val tvSub: TextView = view.findViewById(R.id.tvBrushSubtitle)
        val ivPreview: ImageView = view.findViewById(R.id.ivBrushPreview)
    }
}
